<?php
// File: get_server_time.php
// Deskripsi: menampilkan waktu server dengan ajax

// menampilkan waktu server
echo date('H:i:s');
