/************************************/
/* Program   : maintitik.c */
/* Deskripsi : aplikasi driver modul Titik */
/* NIM/Nama  : */
/* Tanggal   : */
/***********************************/
#include <stdio.h>
#include "titik.h"

int main() {
	//kamus main
	
	
	//algoritma
	printf("Halo, ini driver modul Titik /n");
	//makeTitik(&A);
	
	
	return 0;
}